<?php
/**
 * Plugin Name: Plugin Generator Connector
 * Description: Connect your WordPress site to the Plugin Generator app for direct plugin deployment
 * Version: 1.0.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

class PluginGeneratorConnector {
    private $api_key;
    private $options_name = 'plugin_generator_connector_options';

    public function __construct() {
        // Initialize the plugin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_api_endpoints'));
    }

    public function add_admin_menu() {
        add_options_page(
            'Plugin Generator Connector',
            'Plugin Generator',
            'manage_options',
            'plugin-generator-connector',
            array($this, 'admin_page')
        );
    }

    public function register_settings() {
        register_setting('plugin_generator_connector', $this->options_name);
        
        // Generate API key if it doesn't exist
        $options = get_option($this->options_name);
        if (empty($options['api_key'])) {
            $options['api_key'] = $this->generate_api_key();
            update_option($this->options_name, $options);
        }
    }

    private function generate_api_key() {
        return wp_generate_password(32, false);
    }

    public function admin_page() {
        $options = get_option($this->options_name);
        ?>
        <div class="wrap">
            <h1>Plugin Generator Connector</h1>
            <p>Use this API key to connect your WordPress site to the Plugin Generator app.</p>
            
            <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
                <h2>Your API Key</h2>
                <input type="text" readonly class="regular-text" value="<?php echo esc_attr($options['api_key']); ?>" 
                       style="width: 100%; padding: 10px; font-family: monospace; margin-bottom: 10px;" />
                <button class="button button-primary" onclick="navigator.clipboard.writeText('<?php echo esc_js($options['api_key']); ?>'); alert('API key copied to clipboard!');">
                    Copy to Clipboard
                </button>
            </div>
            
            <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
                <h2>Connection Status</h2>
                <p>Status: <span id="connection-status">Checking...</span></p>
                <p>Last connected: <span id="last-connected"><?php echo isset($options['last_connected']) ? esc_html($options['last_connected']) : 'Never'; ?></span></p>
            </div>
        </div>
        <?php
    }

    public function register_api_endpoints() {
        // Endpoint to validate API key
        register_rest_route('plugin-generator/v1', '/validate', array(
            'methods' => 'POST',
            'callback' => array($this, 'validate_api_key'),
            'permission_callback' => '__return_true'
        ));
        
        // Endpoint to install a plugin
        register_rest_route('plugin-generator/v1', '/install-plugin', array(
            'methods' => 'POST',
            'callback' => array($this, 'install_plugin'),
            'permission_callback' => array($this, 'check_api_key')
        ));
    }

    public function validate_api_key($request) {
        $params = $request->get_params();
        $api_key = isset($params['api_key']) ? sanitize_text_field($params['api_key']) : '';
        
        $options = get_option($this->options_name);
        $valid = $api_key === $options['api_key'];
        
        if ($valid) {
            $options['last_connected'] = current_time('mysql');
            update_option($this->options_name, $options);
            
            return new WP_REST_Response(array(
                'success' => true,
                'site_name' => get_bloginfo('name'),
                'site_url' => get_site_url(),
                'wp_version' => get_bloginfo('version')
            ), 200);
        }
        
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Invalid API key'
        ), 401);
    }

    public function check_api_key($request) {
        $params = $request->get_params();
        $api_key = isset($params['api_key']) ? sanitize_text_field($params['api_key']) : '';
        
        $options = get_option($this->options_name);
        return $api_key === $options['api_key'];
    }

    public function install_plugin($request) {
        if (!class_exists('WP_Filesystem_Direct')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
        }
        
        $params = $request->get_params();
        $plugin_zip = isset($params['plugin_zip']) ? $params['plugin_zip'] : '';
        
        if (empty($plugin_zip)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'No plugin data provided'
            ), 400);
        }
        
        // Decode base64 plugin data
        $decoded = base64_decode($plugin_zip);
        
        // Create temporary file
        $upload_dir = wp_upload_dir();
        $temp_file = $upload_dir['basedir'] . '/plugin-generator-temp.zip';
        
        // Write to file
        $filesystem = new WP_Filesystem_Direct(null);
        $filesystem->put_contents($temp_file, $decoded, FS_CHMOD_FILE);
        
        // Include required files for plugin installation
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        
        // Use the WordPress upgrader to install the plugin
        $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
        $result = $upgrader->install($temp_file);
        
        // Clean up
        $filesystem->delete($temp_file);
        
        if (is_wp_error($result)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $result->get_error_message()
            ), 500);
        }
        
        if (false === $result) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Plugin installation failed'
            ), 500);
        }
        
        // Get the installed plugin file
        $plugin_file = $upgrader->plugin_info();
        
        // Activate the plugin
        $activation_result = activate_plugin($plugin_file);
        
        if (is_wp_error($activation_result)) {
            return new WP_REST_Response(array(
                'success' => true,
                'activated' => false,
                'message' => 'Plugin installed but activation failed: ' . $activation_result->get_error_message()
            ), 200);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'activated' => true,
            'message' => 'Plugin installed and activated successfully'
        ), 200);
    }
}

// Initialize the plugin
$plugin_generator_connector = new PluginGeneratorConnector(); 