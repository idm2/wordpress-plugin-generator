'use client'

import { useState, useEffect } from 'react'
import { Download, Eye, FileCode, Folder, FolderOpen, RefreshCw } from 'lucide-react'
import { AdminDetailsModal } from '@/components/admin-details-modal'
import { FileExplorer } from '@/components/file-explorer'
import { CodeEditor } from '@/components/code-editor'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'

const OPENAI_API_KEY = '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'; // Replace with your actual OpenAI API key

export default function PluginGenerator() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [description, setDescription] = useState('')
  const [generatedCode, setGeneratedCode] = useState('')
  const [pluginName, setPluginName] = useState('my-plugin')
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [fileStructure, setFileStructure] = useState<any[]>([])
  const [previewSiteId, setPreviewSiteId] = useState<string | null>(null)
  const [isCreatingPreview, setIsCreatingPreview] = useState(false)
  const [showAdminModal, setShowAdminModal] = useState(false)
  const [adminDetails, setAdminDetails] = useState<{
    url: string
    username: string
    password: string
  } | null>(null)

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (previewSiteId) {
        deleteSite(previewSiteId)
      }
    }

    window.addEventListener('beforeunload', handleBeforeUnload)

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
      if (previewSiteId) {
        deleteSite(previewSiteId)
      }
    }
  }, [previewSiteId])

  const deleteSite = async (siteId: string) => {
    try {
      await fetch('http://localhost:4000/delete-preview-site', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ siteId }),
      })
      console.log('Preview site deleted successfully')
    } catch (error) {
      console.error('Error deleting preview site:', error)
    }
  }

  const generateCode = async () => {
    if (!description) {
      setError('Please enter a description.')
      return
    }

    setLoading(true)
    setError(null)
    setGeneratedCode('')

    try {
      const result = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an expert WordPress plugin developer. Generate only the raw PHP code for a WordPress plugin. Do not include markdown formatting, code fences, or comments. The code should start with <?php and be production-ready, following WordPress coding standards.'
            },
            { role: 'user', content: `Generate a WordPress plugin that ${description}` }
          ],
          max_tokens: 2000,
          temperature: 0.7
        }),
      })

      const data = await result.json()

      if (data.choices?.[0]?.message?.content) {
        const generatedCode = data.choices[0].message.content
          .replace(/\`\`\`php\n?/, '')
          .replace(/\`\`\`\n?$/, '')
          .trim()

        setGeneratedCode(generatedCode)
        createFileStructure(generatedCode)
      } else {
        setError('Failed to generate code.')
      }
    } catch (err) {
      console.error('Error generating code:', err)
      setError(`Error generating code: ${err instanceof Error ? err.message : 'Unknown error'}`)
    } finally {
      setLoading(false)
    }
  }

  const createFileStructure = (code: string) => {
    const structure = [
      {
        name: pluginName,
        type: "folder",
        children: [
          {
            name: "admin",
            type: "folder",
            children: [
              { 
                name: "css", 
                type: "folder", 
                children: [
                  { name: "admin.css", type: "file", content: "/* Admin styles */" }
                ]
              },
              { 
                name: "js", 
                type: "folder", 
                children: [
                  { name: "admin.js", type: "file", content: "// Admin JavaScript" }
                ]
              },
              { 
                name: "class-admin.php", 
                type: "file", 
                content: "<?php\n// Admin functionality" 
              }
            ]
          },
          {
            name: "includes",
            type: "folder",
            children: [
              { 
                name: "class-loader.php", 
                type: "file", 
                content: "<?php\n// Plugin loader" 
              },
              { 
                name: "class-i18n.php", 
                type: "file", 
                content: "<?php\n// Internationalization" 
              }
            ]
          },
          {
            name: "public",
            type: "folder",
            children: [
              { 
                name: "css", 
                type: "folder", 
                children: [
                  { name: "public.css", type: "file", content: "/* Public styles */" }
                ]
              },
              { 
                name: "js", 
                type: "folder", 
                children: [
                  { name: "public.js", type: "file", content: "// Public JavaScript" }
                ]
              },
              { 
                name: "class-public.php", 
                type: "file", 
                content: "<?php\n// Public functionality" 
              }
            ]
          },
          { 
            name: `${pluginName}.php`, 
            type: "file", 
            content: code 
          }
        ]
      }
    ]

    setFileStructure(structure)
    setSelectedFile(`${pluginName}/${pluginName}.php`)
  }

  const previewPlugin = async () => {
    if (!generatedCode || !pluginName) {
      setError('Please enter a plugin name and generate code first.')
      return
    }

    setLoading(true)
    setError(null)
    setIsCreatingPreview(true)

    try {
      const response = await fetch('http://localhost:4000/preview-plugin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          pluginName,
          code: generatedCode.replace(/\`\`\`php\n?|\`\`\`\n?/g, '')
        }),
      })

      const data = await response.json()
      const siteData = data?.data

      if (siteData?.wp_url) {
        setPreviewSiteId(siteData.id)
        setAdminDetails({
          url: siteData.wp_url,
          username: siteData.wp_username,
          password: siteData.wp_password,
        })
        setShowAdminModal(true)

        const loginUrl = `${siteData.wp_url}/wp-admin/?auto_login=true&s_hash=${siteData.s_hash}`
        const previewWindow = window.open(loginUrl, '_blank')

        if (previewWindow) {
          const checkWindowClosed = setInterval(() => {
            if (previewWindow.closed) {
              clearInterval(checkWindowClosed)
              deleteSite(siteData.id)
              setPreviewSiteId(null)
            }
          }, 1000)
        }
      }
    } catch (err) {
      console.error('Error response:', err)
      setError('Could not create preview site. Please try again.')
    } finally {
      setLoading(false)
      setIsCreatingPreview(false)
    }
  }

  const downloadPlugin = async () => {
    if (!generatedCode || !pluginName) {
      setError('Please generate code and enter a plugin name before downloading.')
      return
    }

    setLoading(true)
    setError(null)

    try {
      const response = await fetch('http://localhost:4000/export-plugin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ pluginName, code: generatedCode }),
      })

      if (!response.ok) {
        throw new Error('Failed to download plugin')
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${pluginName}.zip`
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    } catch (err) {
      setError(`Error downloading plugin: ${err instanceof Error ? err.message : 'Unknown error'}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex h-screen bg-white">
      {/* Left Sidebar - File Explorer */}
      <div className="w-64 border-r">
        <div className="p-4 border-b">
          <h2 className="font-semibold mb-2">Files</h2>
          <div className="h-[calc(100vh-8rem)] overflow-auto">
            <FileExplorer
              files={fileStructure}
              selectedFile={selectedFile}
              onSelectFile={setSelectedFile}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Section */}
        <div className="border-b p-4">
          <h1 className="text-2xl font-bold mb-4">WordPress Plugin Generator</h1>
          <div className="space-y-4">
            <Textarea
              placeholder="Describe the functionality you want (e.g., a plugin that adds a custom post type for reviews)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-[100px]"
            />
            <Input
              type="text"
              placeholder="Plugin Name"
              value={pluginName}
              onChange={(e) => setPluginName(e.target.value)}
            />
            <div className="flex items-center gap-2">
              <Button
                onClick={generateCode}
                disabled={loading || isCreatingPreview}
              >
                {loading ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  'Generate Plugin'
                )}
              </Button>
              {generatedCode && (
                <>
                  <Button
                    variant="outline"
                    onClick={downloadPlugin}
                    disabled={loading || isCreatingPreview}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  <Button
                    variant="outline"
                    onClick={previewPlugin}
                    disabled={loading || isCreatingPreview}
                  >
                    {isCreatingPreview ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Creating preview...
                      </>
                    ) : (
                      <>
                        <Eye className="mr-2 h-4 w-4" />
                        Preview
                      </>
                    )}
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Code Editor / Preview Section */}
        <div className="flex-1 p-4">
          <Card className="h-full">
            <Tabs defaultValue="code" className="h-full">
              <TabsList>
                <TabsTrigger value="code">Code</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
              </TabsList>
              <TabsContent value="code" className="h-[calc(100%-40px)]">
                <CodeEditor
                  selectedFile={selectedFile}
                  fileStructure={fileStructure}
                />
              </TabsContent>
              <TabsContent value="preview" className="h-[calc(100%-40px)]">
                <div className="w-full h-full flex items-center justify-center text-gray-500">
                  Generate and preview a plugin to see it here
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>

      {isCreatingPreview && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="p-6 text-center">
            <RefreshCw className="h-8 w-8 animate-spin text-blue-500 mx-auto mb-4" />
            <p className="text-lg font-semibold">Creating preview site...</p>
            <p className="text-sm text-gray-600 mt-2">
              This may take up to a minute. Please wait.
            </p>
          </Card>
        </div>
      )}

      {error && (
        <div className="absolute bottom-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <AdminDetailsModal
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
        details={adminDetails}
      />
    </div>
  )
}

